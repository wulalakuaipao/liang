package com.lemon.web.day01;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-04 21:35
 * @Desc：
 **/
public class IEDemo {
    public static void main(String[] args) throws InterruptedException {
        //IE环境：selenium.jar + 驱动
        //1、加载驱动
        System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
        //2、创建IEDriver
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //忽略缩放比
        capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
        //忽略安全性
        capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        //设置浏览器初始访问url
//        capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL,
//                "https://www.baidu.com");
        //InternetExplorerOptions
        InternetExplorerDriver driver = new InternetExplorerDriver(capabilities);
        //3、访问百度
        driver.get("https://www.baidu.com");
        Thread.sleep(5000);
        //4、关闭驱动
        driver.quit();
    }
}
