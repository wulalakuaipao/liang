package com.lemon.web.day04;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-11 21:41
 * @Desc：
 **/
public class JSDemo {
    public static void main(String[] args) throws InterruptedException {
        //当无法使用selenium API 定位、点击、滚动实现的某些功能，可以使用js脚本的方式解决。
        //cypress

        RemoteWebDriver driver = getDriver("chrome");
//        driver.get("https://www.12306.cn/index/");
//
//        driver.manage().window().maximize();
//        // 子类 强转 父类  多态
//        JavascriptExecutor jsExecutor = driver;
//        //(String script, Object... args);      //Object... args 可变参数 0 - n  1 - n+1
//        //没有参数
////        String js = "document.getElementById(\"train_date\").removeAttribute(\"readonly\")";
////        //删除readOnly属性之后
//        //一个参数
////        jsExecutor.executeScript(js);
////        String js = "arguments[0].removeAttribute(\"readonly\")";
////        WebElement train_date = driver.findElementByXPath("//input[@id='train_date']");
//        //二个参数
//        String js = "arguments[0].removeAttribute(arguments[1])";
//        WebElement train_date = driver.findElementByXPath("//input[@id='train_date']");
//        jsExecutor.executeScript(js,train_date,"readonly");
//        Thread.sleep(1000);
//        driver.findElementById("train_date").sendKeys("123123123");
//
//        Thread.sleep(1000);
//        //滚动到页面最下面
//        jsExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight+100)");



        driver.get("https://www.ketangpai.com/");
        driver.manage().window().maximize();
        //点击被拦截   这句代码是通过驱动执行（类似手动操作）
        driver.findElementByXPath("//span[text()='登录']").click();

        //js代码，js脚本执行。
        WebElement element = driver.findElementByXPath("//span[text()='登录']");
        JavascriptExecutor javascriptExecutor = driver;
        javascriptExecutor.executeScript("arguments[0].click()",element);
        close(driver);
    }

    public static void close(WebDriver driver) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }



    /**
     * 获取不同浏览器的driver对象
     * @param type  浏览器类型
     * @return
     */
    public static RemoteWebDriver getDriver(String type) {
        RemoteWebDriver driver = null;
        if("chrome".equals(type)) {
//            null.equals("chrome")
            System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        }else if("firefox".equals(type)) {
            System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
            //1.1、如果firefox不是默认路径，配置firefox安装路径
            System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
            //2、创建FirefoxDriver对象
            driver = new FirefoxDriver();
        }else if("edge".equals(type)) {
            System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
            //2、创建EdgeDriver对象
            driver = new EdgeDriver();
        }else if("ie".equals(type)) {
            System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
            //2、创建IEDriver
            DesiredCapabilities capabilities = new DesiredCapabilities();
            //忽略缩放比
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
            //忽略安全性
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //InternetExplorerOptions
            driver = new InternetExplorerDriver(capabilities);
        }else {
            System.out.println("输入的浏览器类型有问题");
        }
        return driver;
    }
}
