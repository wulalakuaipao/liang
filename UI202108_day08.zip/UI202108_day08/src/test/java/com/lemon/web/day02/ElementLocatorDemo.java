package com.lemon.web.day02;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-06 20:12
 * @Desc：
 **/
public class ElementLocatorDemo {
    public static void main(String[] args) {
        //获取浏览器驱动
        RemoteWebDriver driver = getDriver("chrome");
        //访问网站
        driver.get("https://www.baidu.com/");
        //元素定位 原生API
        //id
//        WebElement element = driver.findElement(By.id("kw"));
//        element.sendKeys("柠檬班");
//        driver.findElementById("kw").sendKeys("柠檬班");
        //name
//        driver.findElement(By.name("wd")).sendKeys("柠檬班");
        //tagName 标签名
        //使用驱动打开的网页和我们自己手动打开的网页内容可能有差别，一定以驱动打开的为主。
//        WebElement element = driver.findElement(By.tagName("input"));
//        System.out.println(element.getAttribute("type"));
//        System.out.println(element.getAttribute("name"));
        //className
//        driver.findElement(By.className("s_ipt")).sendKeys("柠檬班");
        //linkText partialLinkText
//        driver.findElement(By.linkText("新闻")).click();
//        driver.findElement(By.partialLinkText("新")).click();
        //关闭驱动
        close(driver);
    }


    public static void close(WebDriver driver) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }

    /**
     * 获取不同浏览器的driver对象
     * @param type  浏览器类型
     * @return
     */
    public static RemoteWebDriver getDriver(String type) {
        RemoteWebDriver driver = null;
        if("chrome".equals(type)) {
//            null.equals("chrome")
            System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        }else if("firefox".equals(type)) {
            System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
            //1.1、如果firefox不是默认路径，配置firefox安装路径
            System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
            //2、创建FirefoxDriver对象
            driver = new FirefoxDriver();
        }else if("edge".equals(type)) {
            System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
            //2、创建EdgeDriver对象
            driver = new EdgeDriver();
        }else if("ie".equals(type)) {
            System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
            //2、创建IEDriver
            DesiredCapabilities capabilities = new DesiredCapabilities();
            //忽略缩放比
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
            //忽略安全性
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //InternetExplorerOptions
            driver = new InternetExplorerDriver(capabilities);
        }else {
            System.out.println("输入的浏览器类型有问题");
        }
        return driver;
    }


}
