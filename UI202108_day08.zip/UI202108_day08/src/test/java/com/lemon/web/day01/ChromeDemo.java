package com.lemon.web.day01;

import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-04 20:32
 * @Desc：
 **/
public class ChromeDemo {
    public static void main(String[] args) throws InterruptedException {
        //chrome如何使用selenium驱动:  selenium.jar   浏览器驱动    浏览器 ，只关心（驱动和浏览器匹配）
        //1、加载驱动
        System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
        //2、创建ChromeDriver对象
        ChromeDriver driver = new ChromeDriver();
        //3、发指令
        driver.get("https://www.baidu.com");
        //driver.post
        Thread.sleep(5000);
        //4、关闭驱动(同时关闭浏览器)
        driver.quit();
    }
}
