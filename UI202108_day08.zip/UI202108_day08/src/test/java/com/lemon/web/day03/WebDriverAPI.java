package com.lemon.web.day03;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-09 20:33
 * @Desc：
 **/
public class WebDriverAPI {


    /**
     * WebDriver 常用API：getCurrentUrl、getTitle、getPageSource、maximize
     */
    public static void main(String[] args) throws InterruptedException {
        RemoteWebDriver driver = getDriver("chrome");
//        driver.get("https://v4.ketangpai.com/");
        driver.get("https://www.baidu.com");
        //getCurrentUrl 获取当前url地址 判断
//        System.out.println(driver.getCurrentUrl());
//        //getTitle 获取网页的标题（源码中title标签的内容）
//        System.out.println(driver.getTitle());
//        //getPageSource 获取网页源码 html
//        System.out.println(driver.getPageSource());
//        //quit 退出驱动，所有网页都关了 driver不能在操作，只能重新创建一个driver
//        //close 关闭当前窗口
//        driver.findElementByLinkText("直播").click();
//        Thread.sleep(2000);
//        //打开一个新的window需要切换之后，才能关闭新打开的window，不然直接关闭的是最先访问的window
//        driver.close();
//        close(driver);
        //Navigation 导航栏对象
//        Navigation navigate = driver.navigate();
//        Thread.sleep(1000);
//        //跳转
//        navigate.to("https://www.baidu.com");
//        //刷新
//        Thread.sleep(1000);
//        navigate.refresh();
//        //后退
//        Thread.sleep(1000);
//        navigate.back();
//        //前进
//        Thread.sleep(1000);
//        navigate.forward();
//        close(driver);

        //window 窗口对象
        Window window = driver.manage().window();
        //最大化
//        window.maximize();

//        System.out.println(window.getSize());
//        System.out.println(window.getPosition());
//        window.maximize();
//        System.out.println(window.getPosition());
//        //窗口大小
//        System.out.println(window.getSize());

        window.setPosition(new Point(150,150));
        //课后尝试 设置窗口大小。
//        window.setSize();

        close(driver);
    }


    public static void close(WebDriver driver) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }



    /**
     * 获取不同浏览器的driver对象
     * @param type  浏览器类型
     * @return
     */
    public static RemoteWebDriver getDriver(String type) {
        RemoteWebDriver driver = null;
        if("chrome".equals(type)) {
//            null.equals("chrome")
            System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        }else if("firefox".equals(type)) {
            System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
            //1.1、如果firefox不是默认路径，配置firefox安装路径
            System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
            //2、创建FirefoxDriver对象
            driver = new FirefoxDriver();
        }else if("edge".equals(type)) {
            System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
            //2、创建EdgeDriver对象
            driver = new EdgeDriver();
        }else if("ie".equals(type)) {
            System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
            //2、创建IEDriver
            DesiredCapabilities capabilities = new DesiredCapabilities();
            //忽略缩放比
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
            //忽略安全性
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //InternetExplorerOptions
            driver = new InternetExplorerDriver(capabilities);
        }else {
            System.out.println("输入的浏览器类型有问题");
        }
        return driver;
    }
}
