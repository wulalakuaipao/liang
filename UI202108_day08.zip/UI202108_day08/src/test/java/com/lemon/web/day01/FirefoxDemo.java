package com.lemon.web.day01;

import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-04 21:16
 * @Desc：
 **/
public class FirefoxDemo {
    public static void main(String[] args) throws InterruptedException {
        //firefox：selenium.jar 和 驱动 和 浏览器都保持一致才能运行成功。
        //1、加载驱动
        System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
        //1.1、如果firefox不是默认路径，配置firefox安装路径
        System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
        //2、创建FirefoxDriver对象
        FirefoxDriver driver = new FirefoxDriver();
        //3、发指令
        driver.get("https://www.baidu.com");
        Thread.sleep(5000); //硬等待
        //4、关闭驱动(同时关闭浏览器)
        driver.quit();
    }
}
