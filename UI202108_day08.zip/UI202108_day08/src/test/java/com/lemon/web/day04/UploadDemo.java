package com.lemon.web.day04;

import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-13 20:38
 * @Desc：
 **/
public class UploadDemo {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.layui.com/demo/upload.html");
        Thread.sleep(1000);
        driver.findElementByXPath("//button[@id='test1']").click();
        //Java运行时对象
        Runtime runtime = Runtime.getRuntime();
        try {
            //执行
            runtime.exec("C:\\Users\\luojie\\Desktop\\upload.exe");
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
