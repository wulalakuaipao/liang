package com.lemon.web.day04;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.Set;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-11 20:18
 * @Desc：
 **/
public class SwitchDemo {
    public static void main(String[] args) throws InterruptedException {

//        iframeSwitch();
//        alertSwitch();
        //window切换

        RemoteWebDriver driver = getDriver("chrome");
        driver.get("https://www.baidu.com/");
        driver.findElementByLinkText("新闻").click();
        //切换window之前先获取所有窗口的handle
        Set<String> windowHandles = driver.getWindowHandles();
        //2 3   a b    a c b
//        Object[] objects = windowHandles.toArray();
        //获取当前窗口的handle
        String currentHandle = driver.getWindowHandle();
        for(String handle : windowHandles) {
            //如果遍历的handle不是当前窗口，切换
            if(!currentHandle.equals(handle)) {
                driver.switchTo().window(handle);
                break;
            }
        }
        Thread.sleep(2000);
        driver.findElementByLinkText("知道").click();

        close(driver);

    }

    //alert 切换
    private static void alertSwitch() throws InterruptedException {
        RemoteWebDriver driver = getDriver("chrome");
        driver.get("C:\\Users\\luojie\\Desktop\\alert_confirm.html");
        //获取当前alert弹窗（前端js点代码：）
        Alert alert = driver.switchTo().alert();
        //获取内容
        System.out.println(alert.getText());
        //点击取消
        Thread.sleep(1000);
        alert.dismiss();
        //再次点击确定
        Thread.sleep(1000);
        alert.accept();
        Thread.sleep(1000);
        //alert消失之后，无须切换 直接定位元素
        driver.findElementByTagName("input").sendKeys("1123123123123");
        close(driver);
    }


    //iframe 切换
    private static void iframeSwitch() throws InterruptedException {
        RemoteWebDriver driver = getDriver("chrome");
        driver.get("http://8.129.91.152:8765/Admin/Index/login.html");
        //登录页面
        driver.findElementByName("admin_name").sendKeys("lemon7");
        driver.findElementByName("admin_pwd").sendKeys("lemonbest");
        driver.findElementByName("code").sendKeys("hapi");
        driver.findElementByCssSelector(".admin_login_btn.denglu").click();
        //后台首页
        Thread.sleep(2000);
        driver.findElementByXPath("//span[text()='业务项目管理']").click();
        //没有切换iframe, 报错：NoSuchElementException: no such element
        Thread.sleep(1000);
        //切换iframe 通过id或name属性切换iframe
//        driver.switchTo().frame("mainFrame");
        WebElement mainFrame = driver.findElementByName("mainFrame");
//        WebElement mainFrame = driver.findElementByName("mainFrame");
        driver.switchTo().frame(mainFrame);
        driver.findElementByXPath("//span[text()='增加业务项目']").click();
        //切换iframe 跳父frame
//        driver.switchTo().parentFrame();
        //切换iframe 跳默认frame，一般就最外层网页。 当有超过两层以上的iframe嵌套使用此方法可直接跳到最外层。
        driver.switchTo().defaultContent();
        //点击后台首页的按钮
        driver.findElementByXPath("//span[text()='用户投资列表']").click();

        close(driver);
    }


    public static void close(WebDriver driver) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }



    /**
     * 获取不同浏览器的driver对象
     * @param type  浏览器类型
     * @return
     */
    public static RemoteWebDriver getDriver(String type) {
        RemoteWebDriver driver = null;
        if("chrome".equals(type)) {
//            null.equals("chrome")
            System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        }else if("firefox".equals(type)) {
            System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
            //1.1、如果firefox不是默认路径，配置firefox安装路径
            System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
            //2、创建FirefoxDriver对象
            driver = new FirefoxDriver();
        }else if("edge".equals(type)) {
            System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
            //2、创建EdgeDriver对象
            driver = new EdgeDriver();
        }else if("ie".equals(type)) {
            System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
            //2、创建IEDriver
            DesiredCapabilities capabilities = new DesiredCapabilities();
            //忽略缩放比
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
            //忽略安全性
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //InternetExplorerOptions
            driver = new InternetExplorerDriver(capabilities);
        }else {
            System.out.println("输入的浏览器类型有问题");
        }
        return driver;
    }
}
