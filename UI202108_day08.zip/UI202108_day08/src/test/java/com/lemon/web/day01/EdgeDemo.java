package com.lemon.web.day01;

import org.openqa.selenium.edge.EdgeDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-04 20:32
 * @Desc：
 **/
public class EdgeDemo {
    public static void main(String[] args) throws InterruptedException {
        //Edge : 驱动和浏览器保持一致
        //1、加载驱动
        System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
        //2、创建EdgeDriver对象
        EdgeDriver driver = new EdgeDriver();
        //3、发指令
        driver.get("https://www.baidu.com");
        Thread.sleep(5000);
        //4、关闭驱动(同时关闭浏览器)
        driver.quit();
    }
}
