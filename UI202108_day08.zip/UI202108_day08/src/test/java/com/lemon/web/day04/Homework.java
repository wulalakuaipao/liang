package com.lemon.web.day04;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-13 20:05
 * @Desc：
 **/
public class Homework {
    public static void main(String[] args) throws InterruptedException {
        RemoteWebDriver driver = getDriver("chrome");
        driver.manage().window().maximize();
        driver.get("http://8.129.91.152:8765/Admin/Index/login.html");
        //登录页面
        driver.findElementByName("admin_name").sendKeys("lemon7");
        driver.findElementByName("admin_pwd").sendKeys("lemonbest");
        driver.findElementByName("code").sendKeys("hapi");
        driver.findElementByCssSelector(".admin_login_btn.denglu").click();
        //后台首页
        Thread.sleep(2000);
        driver.findElementByXPath("//span[text()='业务项目管理']").click();
        //没有切换iframe, 报错：NoSuchElementException: no such element
        Thread.sleep(1000);
        //切换iframe 通过id或name属性切换iframe
//        driver.switchTo().frame("mainFrame");
        WebElement mainFrame = driver.findElementByName("mainFrame");
//        WebElement mainFrame = driver.findElementByName("mainFrame");
        driver.switchTo().frame(mainFrame);
        driver.findElementByXPath("//span[text()='增加业务项目']").click();
        Thread.sleep(1000);
        //子业务类型:
        driver.findElementByXPath("//td[text()='子业务类型:']/following-sibling::td//a").click();
        Thread.sleep(1000);
        driver.findElementById("_easyui_combobox_i5_4").click();
        //项目内容:
        WebElement editFrame = driver.findElementByClassName("ke-edit-iframe");
        driver.switchTo().frame(editFrame);

        driver.findElementByTagName("body").sendKeys("aaasdasdasd444444444441111112222222222");
        Thread.sleep(2000);

        driver.switchTo().parentFrame();
        //点击添加
        driver.findElementByXPath("//span[text()='添加']").click();

        close(driver);
    }


    public static void close(WebDriver driver) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }



    /**
     * 获取不同浏览器的driver对象
     * @param type  浏览器类型
     * @return
     */
    public static RemoteWebDriver getDriver(String type) {
        RemoteWebDriver driver = null;
        if("chrome".equals(type)) {
//            null.equals("chrome")
            System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        }else if("firefox".equals(type)) {
            System.setProperty("webdriver.gecko.driver","src/test/resources/geckodriver.exe");
            //1.1、如果firefox不是默认路径，配置firefox安装路径
            System.setProperty("webdriver.firefox.bin","D:\\azrj\\Mozilla Firefox\\firefox.exe");
            //2、创建FirefoxDriver对象
            driver = new FirefoxDriver();
        }else if("edge".equals(type)) {
            System.setProperty("webdriver.edge.driver","src/test/resources/msedgedriver.exe");
            //2、创建EdgeDriver对象
            driver = new EdgeDriver();
        }else if("ie".equals(type)) {
            System.setProperty("webdriver.ie.driver","src/test/resources/IEDriverServer.exe");
            //2、创建IEDriver
            DesiredCapabilities capabilities = new DesiredCapabilities();
            //忽略缩放比
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
            //忽略安全性
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //InternetExplorerOptions
            driver = new InternetExplorerDriver(capabilities);
        }else {
            System.out.println("输入的浏览器类型有问题");
        }
        return driver;
    }
}
