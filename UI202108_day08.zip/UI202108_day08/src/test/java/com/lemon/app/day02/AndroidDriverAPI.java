package com.lemon.app.day02;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-16 21:15
 * @Desc：
 **/
public class AndroidDriverAPI {
    public static void main(String[] args) throws Exception {
        //所需功能
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //1、确认测试平台
        capabilities.setCapability("platformName", "Android");
        //2、需要测试的设备
        capabilities.setCapability("deviceName", "127.0.0.1:62001");
        //3、测试的app 通过app唯一标识
        capabilities.setCapability("appPackage", "com.lemon.lemonban");
        //4、启用app 调用appActivity
        capabilities.setCapability("appActivity", "com.lemon.lemonban.activity.WelcomeActivity");
        //5、客户端（java脚本）和Appium server 建立连接
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        //6、创建AndroidDriver 对象
        AndroidDriver driver = new AndroidDriver(url, capabilities);
        //获取当前app Activity值，可以用来当作断言条件。 ********
//        System.out.println(driver.currentActivity());
        Thread.sleep(2000);
//        driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"题库\"]").click();
//        System.out.println(driver.currentActivity());
//        //去登陆
//        Thread.sleep(1000);
//        driver.findElementById("com.lemon.lemonban:id/button_go_login").click();
//        //输入手机号码
//        Thread.sleep(1000);
//        System.out.println(driver.currentActivity());
//        //获取app代码源码
//        System.out.println(driver.getPageSource());
        //获取设备信息
//        //获取设备时间
//        System.out.println(driver.getDeviceTime());
//        //获取DPI
//        System.out.println(driver.getDisplayDensity());
//        //获取uiautomation
//        System.out.println(driver.getAutomationName());
//        //获取横屏竖屏状态 有PORTRAIT(竖屏)与LANDSCAPE(横屏)
//        System.out.println(driver.getOrientation());
        //app特有api pressKey() ******** 输入android 对应key，激活对应功能，包括 声音大小，相机，开关机，返回等等。
//        Thread.sleep(3000);
//        KeyEvent keyEvent = new KeyEvent();
//        keyEvent.withKey(AndroidKey.BACK);
//        driver.pressKey(keyEvent);
//        //手机截图文件 ********
//        Thread.sleep(1000);
//        File srcFile = driver.getScreenshotAs(OutputType.FILE);
//        FileUtils.copyFile(srcFile,new File("D://aaa1.png"));
        //坐标点击缺点：兼容性差，更换设备之后一般不能使用。
        TouchAction action = new TouchAction(driver);
        //创建点  x y
        PointOption point = PointOption.point(643,886);
        action.press(point).release().perform();
    }
}
