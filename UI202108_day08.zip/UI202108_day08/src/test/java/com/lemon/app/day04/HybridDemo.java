package com.lemon.app.day04;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-20 20:31
 * @Desc：
 **/
public class HybridDemo {
    public static AndroidDriver driver = null;

    public static void main(String[] args) throws Exception {
        //所需功能
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //1、确认测试平台
        capabilities.setCapability("platformName", "Android");
        //2、需要测试的设备
        capabilities.setCapability("deviceName", "127.0.0.1:62001");
        //3、测试的app 通过app唯一标识
        capabilities.setCapability("appPackage", "com.lemon.lemonban");
        //4、启用app 调用appActivity
        capabilities.setCapability("appActivity", "com.lemon.lemonban.activity.WelcomeActivity");
        //5、记录app用户信息
//        capabilities.setCapability("noReset", true);
        //5、客户端（java脚本）和Appium server 建立连接
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        //6、创建AndroidDriver 对象
        driver = new AndroidDriver(url, capabilities);
        //隐式等待 全局
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //点击柠檬社区
        driver.findElementByXPath("//*[@text='柠檬社区']").click();
        //进入html页面  切换 context 上下文 环境
        Set<String> contextHandles = driver.getContextHandles();
        // NATIVE_APP 表示 元素app  WEBVIEW_com.lemon.lemonban 表示 WEBVIEW控件
//        System.out.println(contextHandles);
//        driver.context("WEBVIEW_com.lemon.lemonban");
        for (String contextHandle : contextHandles) {
            if(contextHandle.contains("WEBVIEW")) {
                driver.context(contextHandle);
                break;
            }
        }
        //当driver切换 context，AndroidDriver -> WebDriver，接下来的操作都是Web操作
        driver.findElementByXPath("//a[text()='注册']").click();

        driver.context("NATIVE_APP");

//        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        //当driver切回到  NATIVE_APP，WebDriver -> AndroidDriver
        driver.findElementByXPath("//android.widget.ImageButton").click();
    }
}
