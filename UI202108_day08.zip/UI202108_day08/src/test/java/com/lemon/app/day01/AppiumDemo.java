package com.lemon.app.day01;

import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-13 21:33
 * @Desc：
 **/
public class AppiumDemo {
    public static void main(String[] args) throws Exception {
        //所需功能
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //1、确认测试平台
        capabilities.setCapability("platformName","Android");
        //2、需要测试的设备
        capabilities.setCapability("deviceName","127.0.0.1:62001");
        //3、测试的app 通过app唯一标识
        capabilities.setCapability("appPackage","com.lemon.lemonban");
        //4、启用app 调用appActivity
        capabilities.setCapability("appActivity","com.lemon.lemonban.activity.WelcomeActivity");
        //5、客户端（java脚本）和Appium server 建立连接
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        //6、创建AndroidDriver 对象
        AndroidDriver driver = new AndroidDriver(url,capabilities);
        Thread.sleep(2000);
//        driver.findElementById("com.lemon.lemonban:id/navigation_my").click();
//        driver.findElementByAccessibilityId("我的柠檬").click();
//        driver.findElementByAndroidUIAutomator("new UiSelector().text(\"柠檬社区\")").click();
//        driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"题库\"]").click();
//        driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"题库\"]")).click();
//        driver.findElement(MobileBy.xpath("//android.widget.FrameLayout[@content-desc=\"题库\"]")).click();


        



    }
}
