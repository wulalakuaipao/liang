package com.lemon.app.day04;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-20 21:04
 * @Desc：
 **/
public class WechatDemo {

    public static AndroidDriver driver = null;

    public static void main(String[] args) throws Exception {
        //所需功能
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //1、确认测试平台
        capabilities.setCapability("platformName", "Android");
        //2、需要测试的设备
        capabilities.setCapability("deviceName", "08e7c5997d2a");
        //3、测试的app 通过app唯一标识
        capabilities.setCapability("appPackage", "com.tencent.mm");
        //4、启用app 调用appActivity
        capabilities.setCapability("appActivity", "com.tencent.mm.ui.LauncherUI");
        //不清楚app数据  ！！！！一定要加！！！！
        capabilities.setCapability("noReset", true);
        // 支持X5内核应用自动化配置
        capabilities.setCapability("recreateChromeDriverSessions", true);
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("androidProcess", "com.tencent.mm:appbrand0");
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        capabilities.setBrowserName("");
        //5、客户端（java脚本）和Appium server 建立连接
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        //6、创建AndroidDriver 对象
        driver = new AndroidDriver(url, capabilities);
        //隐式等待 全局
        Thread.sleep(10000);
        //向下滑动
        SlideDown(2);
        //定位柠檬班app
        Thread.sleep(1000);
        driver.findElementByXPath("//*[@text='柠檬班软件…']").click();
        //切换context
        System.out.println(driver.getContextHandles());
        //NATIVE_APP, WEBVIEW_com.tencent.mm:tools,
        //WEBVIEW_com.tencent.mm:appbrand0, WEBVIEW_com.tencent.mm]
        driver.context("WEBVIEW_com.tencent.mm:appbrand0");
        ////a[contains(text(),'课程')]
        Thread.sleep(3000);
//        driver.findElementByXPath("//a[contains(text(),'课程')]").click();
        System.out.println(driver.getWindowHandles());
        //[CDwindow-3440B1EBA6FB76081386DC0C30129E65,
        // CDwindow-DDD9C52E6879D6CC7FAD6D57E4E94578,
        // CDwindow-C819A017770F5884662E706A63EFB439]

        Set<String> windowHandles = driver.getWindowHandles();
        for (String windowHandle : windowHandles) {
            System.out.println(driver.getCurrentUrl());
            if(driver.getTitle().contains("腾讯课堂柠檬班软件测试")) {
                break;
            }else {
                driver.switchTo().window(windowHandle);
            }
        }
        Thread.sleep(3000);
        driver.findElementByXPath("//a[contains(text(),'课程')]").click();
    }


    /**
     * 向下滑动
     * @param seconds  滑动时间
     */
    public static void SlideDown(int seconds) {
        int height = driver.manage().window().getSize().height;
        int width = driver.manage().window().getSize().width;
        //定位开始滑动的位置
        PointOption startPoint = PointOption.point(width / 2, height / 8);
        PointOption endPoint = PointOption.point(width / 2, height * 7 / 8);
        TouchAction action = new TouchAction(driver);
        //不设置滑动时长，没有滑动的效果
        WaitOptions wait = WaitOptions.waitOptions(Duration.ofSeconds(seconds));
        //从 startPoint 滑动到 endPoint 需要  wait 时间
        action.press(startPoint).waitAction(wait).moveTo(endPoint).release().perform();
    }
}
