package com.lemon.app.day03;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;
import java.time.Duration;

/**
 * @Project: UI202108
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-08-18 20:27
 * @Desc：
 **/
public class SlideDemo {

    public static AndroidDriver driver = null;

    public static void main(String[] args) throws Exception {
        //所需功能
        DesiredCapabilities capabilities = new DesiredCapabilities();
        //1、确认测试平台
        capabilities.setCapability("platformName", "Android");
        //2、需要测试的设备
        capabilities.setCapability("deviceName", "127.0.0.1:62001");
        //3、测试的app 通过app唯一标识
        capabilities.setCapability("appPackage", "com.lemon.lemonban");
        //4、启用app 调用appActivity
        capabilities.setCapability("appActivity", "com.lemon.lemonban.activity.WelcomeActivity");
        //5、客户端（java脚本）和Appium server 建立连接
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        //6、创建AndroidDriver 对象
        driver = new AndroidDriver(url, capabilities);
        //获取当前app Activity值，可以用来当作断言条件。 ********
//        System.out.println(driver.currentActivity());
        Thread.sleep(2000);
        //1、点击题库
        driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"题库\"]").click();
        //2、点击去登陆
        //去登陆
        Thread.sleep(1000);
        driver.findElementById("com.lemon.lemonban:id/button_go_login").click();
        //3、输入手机号码和密码
        Thread.sleep(1000);
        WebElement etMobile = driver.findElementById("com.lemon.lemonban:id/et_mobile");
        etMobile.sendKeys("13323234545");
        WebElement etPassword = driver.findElementById("com.lemon.lemonban:id/et_password");
        etPassword.sendKeys("234545");
        //4、点击登录按钮
        driver.findElementById("com.lemon.lemonban:id/btn_login").click();
        Thread.sleep(3000);
        //5、点击题型
        driver.findElementByAndroidUIAutomator("new UiSelector().text(\"软件测试基础\")").click();
        Thread.sleep(3000);
        //6、点击初级题目
        driver.findElementById("com.lemon.lemonban:id/first_level").click();
        Thread.sleep(3000);
        //滑动


//        SlideUp(2);
//        SlideUp(2);
//        SlideUp(2);
//        SlideUp(2);
//        while(true) {
//            String pageSource1 = driver.getPageSource();
//            if(pageSource1.contains("加载完成")) {
//                break;
//            }
//            SlideUp(2);
//            String pageSource2 = driver.getPageSource();
//            if(pageSource2.contains("加载完成")) {
//                break;
//            }
//        }

        while(true) {
            String beforePageSource = driver.getPageSource();
            SlideUp(2);
            Thread.sleep(2000);
            String afterPageSource = driver.getPageSource();
            //如果滑动前和滑动后源码一致，说明已经到最底，停止滑动。
            if(beforePageSource.equals(afterPageSource)) {
                break;
            }
        }




        //退出驱动
        driver.quit();
    }

    /**
     * 向上滑动
     * @param seconds  滑动时间
     */
    public static void SlideUp(int seconds) {
        int height = driver.manage().window().getSize().height;
        int width = driver.manage().window().getSize().width;
        //定位开始滑动的位置
        PointOption startPoint = PointOption.point(width / 2, height * 3 / 4);
        PointOption endPoint = PointOption.point(width / 2, height / 4);
        TouchAction action = new TouchAction(driver);
        //不设置滑动时长，没有滑动的效果
        WaitOptions wait = WaitOptions.waitOptions(Duration.ofSeconds(seconds));
        //从 startPoint 滑动到 endPoint 需要  wait 时间
        action.press(startPoint).waitAction(wait).moveTo(endPoint).release().perform();
    }

    /**
     * 向下滑动
     * @param seconds  滑动时间
     */
    public static void SlideDown(int seconds) {
        int height = driver.manage().window().getSize().height;
        int width = driver.manage().window().getSize().width;
        //定位开始滑动的位置
        PointOption startPoint = PointOption.point(width / 2, height / 4);
        PointOption endPoint = PointOption.point(width / 2, height * 3 / 4);
        TouchAction action = new TouchAction(driver);
        //不设置滑动时长，没有滑动的效果
        WaitOptions wait = WaitOptions.waitOptions(Duration.ofSeconds(seconds));
        //从 startPoint 滑动到 endPoint 需要  wait 时间
        action.press(startPoint).waitAction(wait).moveTo(endPoint).release().perform();
    }

    /**
     * 向左滑动
     * @param seconds  滑动时间
     */
    public static void SlideLeft(int seconds) {
        int height = driver.manage().window().getSize().height;
        int width = driver.manage().window().getSize().width;
        //定位开始滑动的位置
        PointOption startPoint = PointOption.point(width * 3 / 4, height / 2);
        PointOption endPoint = PointOption.point(width / 4, height  / 2);
        TouchAction action = new TouchAction(driver);
        //不设置滑动时长，没有滑动的效果
        WaitOptions wait = WaitOptions.waitOptions(Duration.ofSeconds(seconds));
        //从 startPoint 滑动到 endPoint 需要  wait 时间
        action.press(startPoint).waitAction(wait).moveTo(endPoint).release().perform();
    }

    /**
     * 向右滑动
     * @param seconds  滑动时间
     */
    public static void SlideRight(int seconds) {
        int height = driver.manage().window().getSize().height;
        int width = driver.manage().window().getSize().width;
        //定位开始滑动的位置
        PointOption startPoint = PointOption.point(width  / 4, height / 2);
        PointOption endPoint = PointOption.point(width * 3 / 4, height  / 2);
        TouchAction action = new TouchAction(driver);
        //不设置滑动时长，没有滑动的效果
        WaitOptions wait = WaitOptions.waitOptions(Duration.ofSeconds(seconds));
        //从 startPoint 滑动到 endPoint 需要  wait 时间
        action.press(startPoint).waitAction(wait).moveTo(endPoint).release().perform();
    }


}
