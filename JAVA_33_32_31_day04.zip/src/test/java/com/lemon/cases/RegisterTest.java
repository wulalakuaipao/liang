package com.lemon.cases;

import com.lemon.commons.BaseTest;
import com.lemon.commons.ExcelUtils;
import com.lemon.pojo.CaseInfo;
import io.restassured.response.Response;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @Project: JAVA_33_32_31
 * @Site: http://www.lemonban.com
 * @Forum: http://testingpai.com
 * @Copyright: ©2021 版权所有 湖南省零檬信息技术有限公司
 * @Author: luojie
 * @Create: 2021-10-25 20:13
 * @Desc：
 **/
public class RegisterTest extends BaseTest {


    @Test(dataProvider = "datas")
    public void test(CaseInfo caseInfo) {
        //1、发送请求
        Response response = request(caseInfo);
        //2、响应断言
        assertResponse(caseInfo, response);
        //3、打印响应
        System.out.println(response.asString());
    }

    @DataProvider
    public Object[] datas() {
        //读取第一个sheet
        List<CaseInfo> caseInfoList = ExcelUtils.getExcelSheetAllData(1);
        return caseInfoList.toArray();
    }


}
